//Animation
function isElementInViewport(elem) {
  var $elem = $(elem);

  // Get the scroll position of the page.
  var scrollElem =
    navigator.userAgent.toLowerCase().indexOf("webkit") != -1 ? "body" : "html";
  var viewportTop = $(window).scrollTop();
  var viewportBottom = viewportTop + $(window).height();

  // Get the position of the element on the page.
  var elemTop = Math.round($elem.offset().top);
  var elemBottom = elemTop + $elem.outerHeight();

  return elemTop < viewportBottom && elemBottom > viewportTop;
}

$(window).scroll(function () {
  extendLine();
});

// Check if it's time to start the animation.
function extendLine() {
  $('[data-animation="true"]').each(function () {
    var $elem = $(this);

    // If the animation has already been started
    if ($elem.attr("data-loop") == "true") {
      if (!isElementInViewport($elem)) {
        if ($elem.hasClass($elem.attr("data-animationclass")))
          $elem.removeClass($elem.attr("data-animationclass"));
      }
    } else {
      if ($elem.hasClass($elem.attr("data-animationclass"))) return;
    }

    if (isElementInViewport($elem)) {
      // Start the animation
      $elem.addClass($elem.attr("data-animationclass"));
    }
  });
}
